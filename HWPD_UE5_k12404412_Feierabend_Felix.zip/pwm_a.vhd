library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

architecture BHV_PWM of PWM is 
signal counter_value : std_ulogic_vector (COUNTER_LEN - 1 downto 0) := (others => '0');

begin

	pwm_proc : process(clk_i) begin
		if rising_edge(clk_i) then
			counter_value <= std_ulogic_vector(unsigned(counter_value) + to_unsigned(1, COUNTER_LEN - 1));
		
			if unsigned(counter_value) < ON_counter_val_i then
				PWM_pin_o <= '1';
			elsif unsigned(counter_value) < Period_counter_val_i then
				PWM_pin_o <= '0';
			else 
				counter_value <= (others => '0');
			end if;
				
		end if;
	end process pwm_proc;

end architecture;