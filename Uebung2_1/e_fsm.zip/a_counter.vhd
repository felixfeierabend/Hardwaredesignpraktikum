library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

use work.all;

architecture bhv_counter of counter is 
signal next_counter : std_ulogic_vector(BITWIDTH - 1 downto 0);
begin
	count : process(clk_i)
	begin
		if rising_edge(clk_i) then
			if restart_strobe_i = '1' then
				next_counter <= (others => '0');
			else 
				next_counter <= std_ulogic_vector(unsigned(next_counter) + to_unsigned(1, BITWIDTH));
			end if;
		end if;
		
		if rst_i = '1' then
			next_counter <= (others => '0');
		end if;
		
		counter_value_o <= next_counter;
	end process;	
	
		
end architecture bhv_counter;